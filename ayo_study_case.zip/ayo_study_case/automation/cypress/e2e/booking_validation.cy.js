/// <reference types="cypress" />

describe("Booking Price Validation", () => {
  beforeEach(() => {
    cy.fixture("booking_data").as("data");
  });

  it("Should validate that booking price matches schedule price", function () {
    const bookings = this.data.bookings;
    const schedule = this.data.schedule;

    bookings.forEach((booking) => {
      const matchedSchedule = schedule.find(
        (item) =>
          item.venue_id === booking.venue_id &&
          item.date === booking.date &&
          item.start_time === booking.start_time &&
          item.end_time === booking.end_time
      );

      expect(matchedSchedule, "Schedule available").to.exist;

      expect(booking.price).to.equal(
        matchedSchedule.price,
        `Price mismatch for booking ID ${booking.booking_id}`
      );
    });
  });
});