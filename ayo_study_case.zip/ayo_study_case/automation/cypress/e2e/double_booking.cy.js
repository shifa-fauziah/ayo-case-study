/// <reference types="cypress" />

describe("Double Booking Detection", () => {
  beforeEach(() => {
    cy.fixture("booking_data").as("data");
  });

  it("Should detect double booking for the same venue, date, and time", function () {
    const bookings = this.data.bookings;

    const keyMap = {};

    bookings.forEach((booking) => {
      const key = `${booking.venue_id}-${booking.date}-${booking.start_time}-${booking.end_time}`;

      if (!keyMap[key]) {
        keyMap[key] = [];
      }

      keyMap[key].push(booking.booking_id);
    });

    Object.values(keyMap).forEach((list) => {
      expect(list.length).to.be.lessThan(
        2,
        `Double booking detected: ${list.join(", ")}`
      );
    });
  });
});